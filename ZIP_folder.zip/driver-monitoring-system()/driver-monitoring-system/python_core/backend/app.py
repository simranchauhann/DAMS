# python_core/backend/app.py
"""
Simple Flask backend to receive detector triggers and save pre+post clips using RingBufferRecorder.

Usage:
  # set token once (or export in env)
  set PY_API_TOKEN=changeme
  set PY_PORT=5000

  # run
  py -3.11 python_core/backend/app.py

Endpoints:
  GET  /health
  POST /start_ring          -> starts camera ring buffer
  POST /stop_ring           -> stops camera ring buffer
  POST /trigger_event       -> detector calls this with JSON {driver_id,label,confidence}
  GET  /list_clips          -> lists saved clip records (id, driver_id, label, confidence, local_path, created_at)
"""
import os
import time
import uuid
from datetime import datetime
from flask import Flask, request, jsonify, abort
from functools import wraps
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime
from sqlalchemy.orm import sessionmaker, declarative_base

# import ring buffer recorder
from python_core.backend.video_handler import RingBufferRecorder, default_output_dir

# ---------- Config from env ----------
PY_API_TOKEN = os.getenv("PY_API_TOKEN", "changeme")
PORT = int(os.getenv("PY_PORT", "5000"))
LOCAL_VIDEO_DIR = os.getenv("LOCAL_VIDEO_DIR", default_output_dir())
POST_SEC = int(os.getenv("POST_SEC", "7"))   # seconds to record after trigger
CAM_ID = int(os.getenv("CAM_ID", "0"))
FPS = int(os.getenv("FPS", "20"))

# ---------- Flask app ----------
app = Flask(__name__)

# ---------- Simple SQLite via SQLAlchemy ----------
DB_PATH = os.path.join(os.path.dirname(__file__), "..", "backend_records.sqlite")
DB_URI = f"sqlite:///{os.path.abspath(DB_PATH)}"
engine = create_engine(DB_URI, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()

class ClipRecord(Base):
    __tablename__ = "clips"
    id = Column(Integer, primary_key=True, index=True)
    uuid = Column(String, unique=True, index=True)
    driver_id = Column(String, index=True)
    label = Column(String)
    confidence = Column(Float)
    local_path = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)

Base.metadata.create_all(bind=engine)

# ---------- Recorder singleton ----------
RECORDER = RingBufferRecorder(cam_id=CAM_ID, fps=FPS, pre_seconds=3.0, out_dir=LOCAL_VIDEO_DIR)
RECORDER_STARTED = False

# ---------- Auth decorator ----------
def require_token(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        token = request.headers.get("X-API-Token") or request.args.get("api_token")
        if not token or token != PY_API_TOKEN:
            return jsonify({"error": "Unauthorized"}), 401
        return fn(*args, **kwargs)
    return wrapper

# ---------- Endpoints ----------
@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "recorder_started": RECORDER_STARTED})

@app.route("/start_ring", methods=["POST"])
@require_token
def start_ring():
    global RECORDER_STARTED
    try:
        RECORDER.start()
        RECORDER_STARTED = True
        return jsonify({"status": "started"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/stop_ring", methods=["POST"])
@require_token
def stop_ring():
    global RECORDER_STARTED
    try:
        RECORDER.stop()
        RECORDER_STARTED = False
        return jsonify({"status": "stopped"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/trigger_event", methods=["POST"])
@require_token
def trigger_event():
    """
    Expected JSON:
      { "driver_id": "DRV001", "label":"drowsy", "confidence":0.92 }
    Behavior:
      - Calls RECORDER.save_clip_with_post(after_seconds=POST_SEC, label=..., confidence=...)
      - Creates a DB record and returns id + path
    """
    if not RECORDER_STARTED:
        # auto-start recorder for convenience
        try:
            RECORDER.start()
        except Exception:
            pass

    payload = request.get_json(silent=True)
    if not payload:
        return jsonify({"error":"invalid json"}), 400
    driver_id = str(payload.get("driver_id", "UNKNOWN"))
    label = str(payload.get("label", "drowsy"))
    try:
        confidence = float(payload.get("confidence", 0.0))
    except Exception:
        confidence = 0.0

    # create unique prefix using uuid
    prefix = "driver"
    try:
        # perform save (this will block while capturing post frames)
        out_path = RECORDER.save_clip_with_post(after_seconds=POST_SEC, label=label, confidence=confidence, driver_id=driver_id, prefix=prefix)
    except Exception as e:
        return jsonify({"error": f"failed to save clip: {e}"}), 500

    # store DB record
    session = SessionLocal()
    try:
        rec = ClipRecord(
            uuid=str(uuid.uuid4()),
            driver_id=driver_id,
            label=label,
            confidence=confidence,
            local_path=os.path.abspath(out_path),
            created_at=datetime.utcnow()
        )
        session.add(rec)
        session.commit()
        session.refresh(rec)
        result = {
            "id": rec.id,
            "uuid": rec.uuid,
            "driver_id": rec.driver_id,
            "label": rec.label,
            "confidence": rec.confidence,
            "local_path": rec.local_path,
            "created_at": rec.created_at.isoformat()
        }
        return jsonify(result), 201
    finally:
        session.close()

@app.route("/list_clips", methods=["GET"])
@require_token
def list_clips():
    session = SessionLocal()
    try:
        rows = session.query(ClipRecord).order_by(ClipRecord.created_at.desc()).limit(100).all()
        out = []
        for r in rows:
            out.append({
                "id": r.id,
                "uuid": r.uuid,
                "driver_id": r.driver_id,
                "label": r.label,
                "confidence": r.confidence,
                "local_path": r.local_path,
                "created_at": r.created_at.isoformat()
            })
        return jsonify(out), 200
    finally:
        session.close()

# ---------- Run ----------
if __name__ == "__main__":
    # Ensure output dir exists
    os.makedirs(LOCAL_VIDEO_DIR, exist_ok=True)
    print("Recorder output dir:", LOCAL_VIDEO_DIR)
    print("Starting Flask on port", PORT)
    # start recorder automatically for convenience (comment if you prefer manual start)
        # Auto-start recorder only when AUTO_START_RECORDER env var is "1"
    if os.getenv("AUTO_START_RECORDER", "1") == "1":
        try:
            RECORDER.start()
            RECORDER_STARTED = True
        except Exception as e:
            print("Warning: failed to start recorder at boot:", e)
    else:
        print("Auto-start recorder disabled by AUTO_START_RECORDER=0")

    app.run(host="0.0.0.0", port=PORT, debug=False)
