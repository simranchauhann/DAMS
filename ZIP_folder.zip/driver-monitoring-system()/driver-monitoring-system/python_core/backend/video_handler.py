# python_core/backend/video_handler.py
"""
Unified video handler:
- ManualRecorder: simple blocking recorder with preview (good for camera tests).
- RingBufferRecorder: background camera thread keeping last N seconds in memory,
  and can save pre+post clips on demand (for event-driven usage).

Env vars used (optional):
 - LOCAL_VIDEO_DIR : where to save recordings (default: python_core/video/recordings)
 - CAM_ID : camera index (default 0)
 - FPS : target FPS (default 20)
 - FRAME_WIDTH : target width (default 640)
 - FRAME_HEIGHT : target height (default 480)
"""
import cv2
import os
import threading
import time
import collections
from datetime import datetime
from typing import List

# ---------- Helpers ----------
def ensure_output_dir(path: str):
    os.makedirs(path, exist_ok=True)
    return path

def timestamp_str():
    return datetime.utcnow().strftime("%Y%m%d_%H%M%S")

def default_output_dir():
    return ensure_output_dir(os.getenv("LOCAL_VIDEO_DIR", os.path.join("python_core", "video", "recordings")))

def make_filename(prefix="driver", driver_id=None, label="event", confidence=None, ext="mp4"):
    parts = [prefix]
    if driver_id:
        parts.append(str(driver_id))
    parts.append(timestamp_str())
    parts.append(label)
    if confidence is not None:
        parts.append(str(int(confidence * 100)))
    filename = "_".join(parts) + f".{ext}"
    return filename

# ---------- Manual Recorder (for quick tests) ----------
class ManualRecorder:
    """
    Blocking manual recorder that opens a preview window.
    Useful for testing camera, resolution, and manual clips.
    """
    def __init__(self, cam_id:int=None, fps:int=None, frame_width:int=None, frame_height:int=None, out_dir:str=None):
        self.cam_id = int(cam_id or os.getenv("CAM_ID", 0))
        self.fps = int(fps or os.getenv("FPS", 20))
        self.frame_width = int(frame_width or os.getenv("FRAME_WIDTH", 640))
        self.frame_height = int(frame_height or os.getenv("FRAME_HEIGHT", 480))
        self.out_dir = default_output_dir() if out_dir is None else ensure_output_dir(out_dir)

    def get_output_path(self, prefix="manual"):
        filename = make_filename(prefix=prefix, label="manual", ext="avi")
        return os.path.join(self.out_dir, filename)

    def record(self, duration:int=30):
        """
        Record for `duration` seconds or until user presses 'q'.
        Shows preview window.
        Returns saved filepath or None on error.
        """
        cap = cv2.VideoCapture(self.cam_id)
        if not cap.isOpened():
            print("[ManualRecorder] ❌ Unable to open camera:", self.cam_id)
            return None

        # try to set resolution (may fail depending on camera)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.frame_width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.frame_height)
        # read actual properties
        actual_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        actual_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        actual_fps = self.fps  # we'll use target fps for writer

        out_path = self.get_output_path()
        fourcc = cv2.VideoWriter_fourcc(*'XVID')
        out = cv2.VideoWriter(out_path, fourcc, actual_fps, (actual_w, actual_h))

        print(f"[ManualRecorder] ✅ Recording started. Save -> {out_path}")
        print("Press 'q' in the preview window to stop early.")

        start_time = time.time()
        while True:
            ret, frame = cap.read()
            if not ret:
                print("[ManualRecorder] ❌ Failed to grab frame.")
                break
            out.write(frame)
            cv2.imshow("Manual Recorder - Press q to stop", frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                print("[ManualRecorder] 🛑 Recording manually stopped.")
                break
            if (time.time() - start_time) >= duration:
                print("[ManualRecorder] ⏱️ Duration reached.")
                break

        cap.release()
        out.release()
        cv2.destroyAllWindows()
        print("[ManualRecorder] 🎥 Saved:", out_path)
        return out_path

# ---------- Ring Buffer Recorder (production / headless) ----------
class FrameRingBuffer:
    """
    Thread-safe ring buffer for frames. Stores up to maxlen frames.
    Frames are stored as BGR numpy arrays (as returned by cv2).
    """
    def __init__(self, maxlen:int=150):
        self.buffer = collections.deque(maxlen=maxlen)
        self.lock = threading.Lock()

    def add(self, frame):
        with self.lock:
            # store a shallow copy to avoid cross-thread modify issues
            self.buffer.append(frame.copy())

    def get_all(self) -> List:
        with self.lock:
            return list(self.buffer)

    def clear(self):
        with self.lock:
            self.buffer.clear()

    def __len__(self):
        with self.lock:
            return len(self.buffer)

class RingBufferRecorder:
    """
    Background camera thread that keeps the last N seconds in memory.
    Use save_clip_with_post() to write pre-buffer + post seconds to disk.
    """
    def __init__(self,
                 cam_id:int=None,
                 fps:int=None,
                 frame_width:int=None,
                 frame_height:int=None,
                 pre_seconds:float=3.0,
                 out_dir:str=None):
        self.cam_id = int(cam_id or os.getenv("CAM_ID", 0))
        self.fps = int(fps or os.getenv("FPS", 20))
        self.frame_width = int(frame_width or os.getenv("FRAME_WIDTH", 640))
        self.frame_height = int(frame_height or os.getenv("FRAME_HEIGHT", 480))

        self.pre_seconds = float(pre_seconds)
        self.pre_frames = max(1, int(self.pre_seconds * self.fps))
        self.ring = FrameRingBuffer(maxlen=self.pre_frames)

        self.out_dir = default_output_dir() if out_dir is None else ensure_output_dir(out_dir)

        self.capture = None
        self.running = False
        self.thread = None
        self.lock = threading.Lock()
        self.frame_size = (self.frame_width, self.frame_height)

    def start(self):
        """Start camera thread (idempotent)."""
        with self.lock:
            if self.running:
                return
            self.capture = cv2.VideoCapture(self.cam_id)
            # try set resolution
            self.capture.set(cv2.CAP_PROP_FRAME_WIDTH, self.frame_width)
            self.capture.set(cv2.CAP_PROP_FRAME_HEIGHT, self.frame_height)
            # note: not showing preview; headless mode
            self.running = True
            self.thread = threading.Thread(target=self._read_loop, daemon=True)
            self.thread.start()
            print("[RingBufferRecorder] ✅ Camera thread started (cam_id=%s fps=%s)" % (self.cam_id, self.fps))

    def stop(self):
        """Stop thread and release camera."""
        with self.lock:
            self.running = False
        if self.thread:
            self.thread.join(timeout=1.0)
        if self.capture:
            self.capture.release()
        print("[RingBufferRecorder] 🛑 Camera thread stopped")

    def _read_loop(self):
        """Continuously read frames into ring buffer."""
        while self.running:
            ret, frame = self.capture.read()
            if not ret:
                time.sleep(0.05)
                continue
            # ensure consistent size
            try:
                frame = cv2.resize(frame, self.frame_size)
            except Exception:
                # if resize fails, fallback to raw frame
                pass
            self.ring.add(frame)
            time.sleep(1.0 / self.fps)

    def save_clip_with_post(self, after_seconds:int=7, label:str="event", confidence:float=None, driver_id:str=None, prefix="driver"):
        """
        Save the current ring buffer (pre buffer) + `after_seconds` frames from live camera into a video file.
        Returns local filepath.

        Use this when an AI detector triggers an event.
        """
        # read preframes snapshot
        pre_frames = self.ring.get_all()
        filename = make_filename(prefix=prefix, driver_id=driver_id, label=label, confidence=confidence, ext="mp4")
        out_path = os.path.join(self.out_dir, filename)
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")  # .mp4
        out = cv2.VideoWriter(out_path, fourcc, self.fps, self.frame_size)

        # write pre frames
        for f in pre_frames:
            out.write(f)

        # capture 'after' frames live
        frames_to_capture = max(0, int(after_seconds * self.fps))
        for _ in range(frames_to_capture):
            # read directly from capture to get post-event frames
            ret, frame = self.capture.read()
            if not ret:
                break
            try:
                frame = cv2.resize(frame, self.frame_size)
            except Exception:
                pass
            out.write(frame)
            time.sleep(1.0 / self.fps)

        out.release()
        # optionally clear ring buffer to avoid duplicate content for next events
        self.ring.clear()
        print(f"[RingBufferRecorder] 🎥 Saved clip: {out_path} (pre={len(pre_frames)} post={frames_to_capture})")
        return out_path

# ---------- Quick manual test runner ----------
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Video handler utility (manual or ring-buffer).")
    parser.add_argument("--mode", choices=["manual", "ring"], default="manual", help="Which mode to run.")
    parser.add_argument("--duration", type=int, default=30, help="Duration in seconds for manual mode.")
    parser.add_argument("--pre", type=float, default=3.0, help="Pre seconds for ring buffer.")
    parser.add_argument("--post", type=int, default=7, help="Post seconds to record when saving clip.")
    parser.add_argument("--driver", type=str, default="DRV001", help="Driver id used in filename when saving clip.")
    args = parser.parse_args()

    if args.mode == "manual":
        mr = ManualRecorder()
        out = mr.record(duration=args.duration)
        print("Manual recording saved to:", out)
    else:
        rb = RingBufferRecorder(pre_seconds=args.pre)
        rb.start()
        print("[Test] Ring buffer running. Wait a few seconds to fill buffer.")
        try:
            # fill buffer for 5 seconds
            time.sleep(max(2, args.pre + 1))
            print("[Test] Now saving a clip (pre + post).")
            path = rb.save_clip_with_post(after_seconds=args.post, label="test_event", confidence=0.9, driver_id=args.driver)
            print("Saved clip:", path)
        finally:
            rb.stop()
