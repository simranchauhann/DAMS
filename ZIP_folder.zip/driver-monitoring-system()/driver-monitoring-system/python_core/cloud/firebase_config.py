# backend/firebase_config.py
# Put your Firebase service account JSON path in env var FIREBASE_CRED_PATH
import os
import firebase_admin
from firebase_admin import credentials, storage

def init_firebase():
    cred_path = os.getenv("FIREBASE_CRED_PATH")
    bucket_name = os.getenv("FIREBASE_BUCKET")
    if not cred_path or not bucket_name:
        raise RuntimeError("Set FIREBASE_CRED_PATH and FIREBASE_BUCKET env vars")

    if not firebase_admin._apps:
        cred = credentials.Certificate(cred_path)
        firebase_admin.initialize_app(cred, {
            "storageBucket": bucket_name
        })
    return storage.bucket()

# Usage:
# bucket = init_firebase()
# blob = bucket.blob("path/in/bucket.mp4")
# blob.upload_from_filename(local_path)
