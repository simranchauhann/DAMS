# save_patches.py
import cv2
from pathlib import Path

ROOT = Path(__file__).resolve().parent
out = ROOT / "debug_patches"
out.mkdir(exist_ok=True)
cap = cv2.VideoCapture(0)
eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_eye.xml")
saved = 0
print("Saving up to 20 patches. Press q to quit early.")
while saved < 20:
    ret, frame = cap.read()
    if not ret:
        break
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    eyes = eye_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
    for (ex,ey,ew,eh) in eyes:
        p = frame[ey:ey+eh, ex:ex+ew]
        if p.size == 0:
            continue
        fname = out / f"patch_{saved:02d}.jpg"
        cv2.imwrite(str(fname), p)
        print("Saved", fname)
        saved += 1
        if saved >= 20:
            break
    cv2.imshow("frame", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
cap.release()
cv2.destroyAllWindows()
print("done, saved", saved)
