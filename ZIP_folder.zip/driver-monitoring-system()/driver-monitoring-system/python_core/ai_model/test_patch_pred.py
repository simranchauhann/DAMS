# test_patch_pred.py
import tensorflow as tf, cv2, numpy as np, sys
from pathlib import Path
MODEL = Path(__file__).resolve().parent / "models" / "cew_best.h5"
if not MODEL.exists():
    print("Model not found:", MODEL); sys.exit(1)
model = tf.keras.models.load_model(str(MODEL))
img = cv2.imread("debug_patches/patch_00.jpg")  # change index if needed
if img is None:
    print("patch not found"); sys.exit(1)
img = cv2.resize(img, (96,96)).astype("float32")/255.0
pred = model.predict(img[np.newaxis,...], verbose=0)[0][0]
print("Model closed_prob:", pred)
