﻿# train_cew_with_classweight.py
"""
Train a simple CEW eye-open/closed classifier with automatic class weights.
Places:
 - expects data at ./data/{train,val,test}/{open,closed}
 - saves best model to ./models/cew_best.h5
"""

import os
from pathlib import Path
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models
from sklearn.utils import class_weight
from sklearn.metrics import confusion_matrix, classification_report

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
MODEL_DIR = ROOT / "models"
MODEL_DIR.mkdir(exist_ok=True)

BATCH_SIZE = 32
IMG_SIZE = (96, 96)
EPOCHS = 30
SEED = 123

train_dir = DATA_DIR / "train"
val_dir = DATA_DIR / "val"
test_dir = DATA_DIR / "test"

# --- create datasets ---
train_ds = tf.keras.preprocessing.image_dataset_from_directory(
    train_dir, label_mode="binary", image_size=IMG_SIZE, batch_size=BATCH_SIZE, seed=SEED
)
val_ds = tf.keras.preprocessing.image_dataset_from_directory(
    val_dir, label_mode="binary", image_size=IMG_SIZE, batch_size=BATCH_SIZE, shuffle=False
)
test_ds = tf.keras.preprocessing.image_dataset_from_directory(
    test_dir, label_mode="binary", image_size=IMG_SIZE, batch_size=BATCH_SIZE, shuffle=False
)

AUTOTUNE = tf.data.AUTOTUNE
train_ds = train_ds.cache().prefetch(buffer_size=AUTOTUNE)
val_ds = val_ds.cache().prefetch(buffer_size=AUTOTUNE)
test_ds = test_ds.cache().prefetch(buffer_size=AUTOTUNE)

# --- augmentation (safe list) ---
data_augmentation = tf.keras.Sequential([
    layers.RandomFlip("horizontal"),
    layers.RandomRotation(0.06),
    layers.RandomTranslation(0.05, 0.05),
    layers.RandomContrast(0.10),
])

# --- model definition ---
def build_model(input_shape=IMG_SIZE + (3,)):
    inputs = layers.Input(shape=input_shape, name="input_layer")
    x = data_augmentation(inputs)
    x = layers.Rescaling(1.0 / 255.0)(x)

    x = layers.Conv2D(32, 3, activation="relu", padding="same")(x)
    x = layers.MaxPooling2D()(x)
    x = layers.Conv2D(64, 3, activation="relu", padding="same")(x)
    x = layers.MaxPooling2D()(x)
    x = layers.Conv2D(128, 3, activation="relu", padding="same")(x)
    x = layers.MaxPooling2D()(x)

    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dropout(0.4)(x)
    x = layers.Dense(64, activation="relu")(x)
    outputs = layers.Dense(1, activation="sigmoid")(x)
    return models.Model(inputs, outputs)

model = build_model()
model.compile(
    optimizer=tf.keras.optimizers.Adam(learning_rate=1e-4),
    loss="binary_crossentropy",
    metrics=["accuracy", tf.keras.metrics.AUC(name="auc")]
)
model.summary()

# ------------------ Robust class-weight computation (REPLACED BLOCK) ------------------
# Collect labels as plain Python ints to avoid unhashable types
y_train = []
for images, labels in train_ds:             # iterate over batches
    arr = labels.numpy().astype(int)
    y_train.extend(int(x) for x in arr)

y_train = np.array(y_train, dtype=int)
if y_train.size == 0:
    raise RuntimeError("No training images found. Check data/train/...")

# Compute class weights using sklearn if available; fallback to manual balanced weights
try:
    cw = class_weight.compute_class_weight(class_weight="balanced", classes=np.unique(y_train), y=y_train)
    class_weight_dict = {int(cls): float(w) for cls, w in zip(np.unique(y_train), cw)}
except Exception:
    unique, counts = np.unique(y_train, return_counts=True)
    total = y_train.size
    n_classes = unique.size
    class_weight_dict = {int(u): float(total / (n_classes * c)) for u, c in zip(unique, counts)}

print("Computed class weights:", class_weight_dict)
# ------------------ end REPLACED BLOCK ------------------

# --- callbacks ---
checkpoint_path = str(MODEL_DIR / "cew_best.h5")
callbacks = [
    tf.keras.callbacks.ModelCheckpoint(checkpoint_path, save_best_only=True, monitor="val_auc", mode="max"),
    tf.keras.callbacks.EarlyStopping(monitor="val_auc", patience=6, mode="max", restore_best_weights=True),
    tf.keras.callbacks.ReduceLROnPlateau(monitor="val_auc", factor=0.5, patience=3, mode="max")
]

# --- training ---
history = model.fit(
    train_ds,
    epochs=EPOCHS,
    validation_data=val_ds,
    callbacks=callbacks,
    class_weight=class_weight_dict
)

# --- evaluation on test set ---
print("Evaluating on test set...")
model = tf.keras.models.load_model(checkpoint_path)  # best model
y_true, y_pred = [], []
for images, labels in test_ds:
    preds = model.predict(images).ravel()
    y_pred.extend((preds > 0.5).astype(int).tolist())
    y_true.extend(labels.numpy().astype(int).tolist())

print("Confusion Matrix:")
print(confusion_matrix(y_true, y_pred))
print(classification_report(y_true, y_pred, target_names=["open", "closed"]))

print("Saved best model ->", checkpoint_path)
