#!/usr/bin/env python3
"""
Drowsiness detector (calibrated for tiny raw model outputs)

- Calibrates raw model outputs (which may be small, e.g. 0.03-0.08) using a sliding window
  so that effective_closed_prob is high when eyes are closed and low when open.
- Shows both raw and calibrated (effective) probabilities on-screen and logs both.
- Use --no-calibrate to disable sliding-window calibration and use simple flipped prob (1-raw).
- Controls: q, g, o, c, +, -, s  (same as before)
"""

import argparse
import csv
import sys
import time
from collections import deque
from pathlib import Path

import cv2
import numpy as np

# lazy import TF to keep startup quick if only evaluating logs
try:
    import tensorflow as tf
except Exception:
    tf = None

# for evaluation
try:
    from sklearn.metrics import precision_recall_fscore_support, confusion_matrix
    import pandas as pd
except Exception:
    pd = None

ROOT = Path(__file__).resolve().parent
DEFAULT_MODEL = ROOT / "models" / "cew_finetuned.keras"
IMG_SIZE = (96, 96)

# Default settings (modifiable during runtime)
CLOSED_PROB_THRESHOLD = 0.6    # threshold on calibrated effective_closed_prob
CLOSED_SECONDS_ALERT = 1.5      # seconds of continuous closed eyes to trigger alert
SCORE_SMOOTHING = 3             # moving average window for aggregated raw score
CALIB_WINDOW_SECONDS = 8.0      # sliding window length in seconds for calibration
MIN_CALIB_SAMPLES = 20          # minimum samples to enable calibration
EPS = 1e-6

# Haar cascades (used for eye/face ROI)
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
eyes_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_eye.xml")


class DrowsinessDetector:
    def __init__(self, model_path: Path):
        if not model_path.exists():
            raise FileNotFoundError(f"Model not found at {model_path}")
        if tf is None:
            raise RuntimeError("TensorFlow not available in this environment. Install tensorflow.")
        print(f"Loading model from {model_path}")
        self.model = tf.keras.models.load_model(str(model_path))
        self.raw_window = deque()  # recent raw_smooth values for calibration
        self.score_window = deque(maxlen=10)  # smoothing window (we'll use SCORE_SMOOTHING externally)

    def predict_eye_patch(self, patch: np.ndarray) -> float:
        if patch is None or patch.size == 0:
            return 0.0
        try:
            img = cv2.resize(patch, IMG_SIZE)
        except Exception:
            return 0.0
        img = img.astype("float32") / 255.0
        img = np.expand_dims(img, 0)
        pred = float(self.model.predict(img, verbose=0).ravel()[0])
        return pred  # raw model output (small values in your case)

    def analyze_frame(self, frame: np.ndarray, smoothing=SCORE_SMOOTHING):
        draw = frame.copy()
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
        probs = []
        # try faces first, then fallback to whole-frame eye detection
        for (fx, fy, fw, fh) in faces:
            roi_gray = gray[fy:fy+fh, fx:fx+fw]
            eyes = eyes_cascade.detectMultiScale(roi_gray, scaleFactor=1.1, minNeighbors=5)
            if len(eyes) == 0:
                eyes = eyes_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
            for (ex, ey, ew, eh) in eyes:
                # if eye found inside face ROI, convert to absolute coords
                if ex + ew <= fw and ey + eh <= fh:
                    ex_abs = fx + ex
                    ey_abs = fy + ey
                else:
                    ex_abs = ex
                    ey_abs = ey
                patch = frame[ey_abs:ey_abs+eh, ex_abs:ex_abs+ew]
                prob = self.predict_eye_patch(patch)
                probs.append(prob)
                cv2.rectangle(draw, (ex_abs, ey_abs), (ex_abs+ew, ey_abs+eh), (0,255,0), 1)
                cv2.putText(draw, f"Raw:{prob:.3f}", (ex_abs, max(ey_abs-6,0)), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0,255,0), 1)

        if len(probs) == 0:
            raw_agg = 0.0
        else:
            raw_agg = float(np.mean(probs))

        # smoothing (moving average)
        self.score_window.append(raw_agg)
        if len(self.score_window) > smoothing:
            self.score_window.popleft()
        raw_smooth = float(np.mean(self.score_window))

        # push to raw calibration window (we'll manage length externally based on FPS)
        timestamp = time.time()
        self.raw_window.append((timestamp, raw_smooth))

        return draw, raw_smooth, len(probs)

    def get_calibrated_effective(self, now=None, window_seconds=CALIB_WINDOW_SECONDS, no_calibrate=False):
        """Compute calibrated effective_closed_prob from raw_window.
           If no_calibrate True -> use simple flip: effective = 1 - raw
           Otherwise compute min/max over recent window and map:
             effective = (max_recent - raw) / (max_recent - min_recent + EPS)
        """
        if now is None:
            now = time.time()
        # collect recent values
        recent = [v for (t, v) in self.raw_window if now - t <= window_seconds]
        # if not enough samples use all
        if len(recent) < MIN_CALIB_SAMPLES:
            recent = [v for (_, v) in self.raw_window]  # fallback to whole buffer

        if len(recent) == 0:
            return 0.0  # cannot calibrate

        raw_current = recent[-1]

        if no_calibrate:
            # simple flip (legacy)
            return max(0.0, min(1.0, 1.0 - raw_current))

        # compute min/max
        rmin = float(min(recent))
        rmax = float(max(recent))
        if (rmax - rmin) < EPS:
            # no dynamic range — fallback to simple flip scaled
            return max(0.0, min(1.0, (rmax - raw_current) ))  # small fallback
        # map so that raw near rmax -> effective near 0 (open), raw near rmin -> effective near 1 (closed)
        eff = (rmax - raw_current) / (rmax - rmin + EPS)
        # clamp
        eff = max(0.0, min(1.0, eff))
        return eff


def save_log_row(csv_path, row):
    header = ['ts', 'frame_idx', 'raw_prob', 'eff_prob', 'predicted_closed', 'gt_label', 'notes']
    write_header = not Path(csv_path).exists()
    with open(csv_path, 'a', newline='') as f:
        writer = csv.writer(f)
        if write_header:
            writer.writerow(header)
        writer.writerow(row)


def eval_log(csv_path):
    if pd is None:
        print("pandas/scikit-learn not installed. Install pandas and scikit-learn to use --eval")
        return
    df = pd.read_csv(csv_path)
    if 'gt_label' not in df.columns:
        print("No ground-truth labels found in CSV. Use labeling mode to add GT.")
        return
    df = df.dropna(subset=['gt_label'])
    if df.empty:
        print("No GT rows to evaluate.")
        return
    y_true = df['gt_label'].astype(int).values
    y_pred = df['predicted_closed'].astype(int).values
    p, r, f1, _ = precision_recall_fscore_support(y_true, y_pred, average='binary', pos_label=1, zero_division=0)
    print("Evaluation results:")
    print(f"Precision (closed): {p:.3f}")
    print(f"Recall (closed):    {r:.3f}")
    print(f"F1 (closed):        {f1:.3f}")
    print("Confusion Matrix:")
    print(confusion_matrix(y_true, y_pred))
    return


def run(source, model_path, save_log=None, save_snaps=False, no_show=False, no_calibrate=False):
    global CLOSED_PROB_THRESHOLD, CLOSED_SECONDS_ALERT, SCORE_SMOOTHING
    det = DrowsinessDetector(Path(model_path))

    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open source: {source}")
    fps = cap.get(cv2.CAP_PROP_FPS)
    if fps is None or fps == 0 or np.isnan(fps):
        fps = 25.0
    frames_alert = int(CLOSED_SECONDS_ALERT * fps)
    calib_maxlen = int(max(1, CALIB_WINDOW_SECONDS * fps))
    print(f"Video FPS: {fps:.1f}, frames_alert={frames_alert}, CLOSED_PROB_THRESHOLD={CLOSED_PROB_THRESHOLD}, calibrate_window={CALIB_WINDOW_SECONDS}s")

    consecutive_closed = 0
    frame_idx = 0
    label_mode = False

    # We'll maintain a deque of raw timestamps automatically inside detector.raw_window
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                print("Stream ended or cannot fetch frame")
                break
            annotated, raw_smooth, num_eyes = det.analyze_frame(frame, smoothing=SCORE_SMOOTHING)

            # remove old entries from raw_window beyond a buffer of 3x window to avoid growth
            now = time.time()
            while det.raw_window and (now - det.raw_window[0][0] > CALIB_WINDOW_SECONDS * 3):
                det.raw_window.popleft()

            # compute calibrated effective prob
            eff = det.get_calibrated_effective(now=now, window_seconds=CALIB_WINDOW_SECONDS, no_calibrate=no_calibrate)

            # predict using calibrated effective prob
            predicted_closed = int(eff >= CLOSED_PROB_THRESHOLD)
            if predicted_closed:
                consecutive_closed += 1
            else:
                consecutive_closed = 0

            # overlay info: show raw and effective
            cv2.putText(annotated, f"Raw={raw_smooth:.4f}", (10, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,200,255), 2)
            cv2.putText(annotated, f"Eff={eff:.3f}", (10, 52), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,200,255), 2)
            cv2.putText(annotated, f"Consec={consecutive_closed}/{frames_alert}", (10, 82), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,200,255), 2)
            cv2.putText(annotated, f"Thresh={CLOSED_PROB_THRESHOLD:.2f}", (10, 112), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,200,255), 2)
            if label_mode:
                cv2.putText(annotated, "LABEL MODE ON (press o/c)", (10, 142), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,0,255), 2)

            # if alert triggered
            if consecutive_closed >= frames_alert:
                cv2.putText(annotated, "DROWSY! ALERT", (10, 180), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0,0,255), 3)
                if save_snaps:
                    snap_p = ROOT / 'alert_snaps'
                    snap_p.mkdir(exist_ok=True)
                    fname = snap_p / f"alert_{int(time.time())}_f{frame_idx}.jpg"
                    cv2.imwrite(str(fname), annotated)

            # logging row: write raw and effective
            if save_log:
                row = [time.time(), frame_idx, f"{raw_smooth:.6f}", f"{eff:.6f}", int(predicted_closed), None, '']
                save_log_row(save_log, row)

            if not no_show:
                cv2.imshow('Drowsiness Detector', annotated)

            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('g'):
                label_mode = not label_mode
                print(f"Label mode = {label_mode}")
            elif key == ord('o') and label_mode:
                if save_log:
                    row = [time.time(), frame_idx, f"{raw_smooth:.6f}", f"{eff:.6f}", int(predicted_closed), 0, 'user_label_open']
                    save_log_row(save_log, row)
                    print(f"Saved GT=open at frame {frame_idx}")
            elif key == ord('c') and label_mode:
                if save_log:
                    row = [time.time(), frame_idx, f"{raw_smooth:.6f}", f"{eff:.6f}", int(predicted_closed), 1, 'user_label_closed']
                    save_log_row(save_log, row)
                    print(f"Saved GT=closed at frame {frame_idx}")
            elif key == ord('+'):
                CLOSED_PROB_THRESHOLD = min(0.99, CLOSED_PROB_THRESHOLD + 0.05)
                print("Threshold ->", CLOSED_PROB_THRESHOLD)
            elif key == ord('-'):
                CLOSED_PROB_THRESHOLD = max(0.05, CLOSED_PROB_THRESHOLD - 0.05)
                print("Threshold ->", CLOSED_PROB_THRESHOLD)
            elif key == ord('s'):
                snap_p = ROOT / 'manual_snaps'
                snap_p.mkdir(exist_ok=True)
                fname = snap_p / f"snap_{int(time.time())}_f{frame_idx}.jpg"
                cv2.imwrite(str(fname), annotated)
                print("Saved snapshot ->", fname)

            frame_idx += 1

    finally:
        cap.release()
        cv2.destroyAllWindows()
        print("Exited run loop. Logs saved to:", save_log if save_log else 'none')


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--video', type=str, help='Path to video file')
    ap.add_argument('--cam', type=int, default=0, help='Camera index')
    ap.add_argument('--model', type=str, default=str(DEFAULT_MODEL), help='Model path')
    ap.add_argument('--save-log', type=str, help='CSV path to append predictions and optional GT labels')
    ap.add_argument('--save-snaps', action='store_true', help='Save alert snapshots')
    ap.add_argument('--no-show', action='store_true', help='Do not display GUI window')
    ap.add_argument('--eval', type=str, help='Evaluate an existing CSV log and print PRF (requires pandas+sklearn)')
    ap.add_argument('--no-calibrate', action='store_true', help='Disable sliding-window calibration and use simple 1-raw flip')
    args = ap.parse_args()

    if args.eval:
        eval_log(args.eval)
        sys.exit(0)

    source = args.video if args.video else args.cam
    run(source, args.model, save_log=args.save_log, save_snaps=args.save_snaps, no_show=args.no_show, no_calibrate=args.no_calibrate)
