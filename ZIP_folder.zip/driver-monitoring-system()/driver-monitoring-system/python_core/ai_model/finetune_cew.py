# finetune_cew.py
"""
Fine-tune CEW eye model (final corrected).
- Expects images in custom_cew/open and custom_cew/closed
- Saves checkpoint weights to models/cew_finetuned.weights.h5
- Finally saves full model to models/cew_finetuned.keras
"""
import tensorflow as tf
from pathlib import Path
import numpy as np
from sklearn.utils import class_weight

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "custom_cew"
MODEL_DIR = ROOT / "models"
MODEL_DIR.mkdir(exist_ok=True)
BASE_MODEL_PATH = MODEL_DIR / "cew_best.h5"
WEIGHTS_OUT = MODEL_DIR / "cew_finetuned.weights.h5"   # <- must end with .weights.h5 when save_weights_only=True
FINAL_MODEL_OUT = MODEL_DIR / "cew_finetuned.keras"    # full model saved here

IMG_SIZE = (96, 96)
BATCH = 8
EPOCHS = 8
LR = 1e-5
AUTOTUNE = tf.data.AUTOTUNE

if not BASE_MODEL_PATH.exists():
    raise FileNotFoundError(f"Base model not found: {BASE_MODEL_PATH}. Place cew_best.h5 there first.")

print("Loading base model:", BASE_MODEL_PATH)
base = tf.keras.models.load_model(str(BASE_MODEL_PATH))

print("Loading dataset (batch_size=1) for robust label extraction and mapping...")
raw_ds = tf.keras.preprocessing.image_dataset_from_directory(
    DATA_DIR,
    labels="inferred",
    label_mode="binary",
    image_size=(256, 256),
    batch_size=1,  # important
    shuffle=True,
    seed=42,
)

# collect labels robustly
print("Collecting labels...")
y_list = []
for img_b, y_b in raw_ds:
    v = y_b.numpy().ravel()[0]
    y_list.append(int(v))
if len(y_list) == 0:
    raise RuntimeError("No images found in custom_cew/. Run collect_eyes.py to capture data.")
unique, counts = np.unique(np.array(y_list, dtype=int), return_counts=True)
print("Found class counts:", dict(zip(unique.tolist(), counts.tolist())))

# compute class weights
cw = class_weight.compute_class_weight(class_weight="balanced", classes=np.unique(y_list), y=np.array(y_list, dtype=int))
class_weight_dict = {int(c): float(w) for c, w in zip(np.unique(y_list), cw)}
print("Computed class weights:", class_weight_dict)

# preprocess helper
def preprocess_image_numpy(img_np):
    img_np = np.asarray(img_np)
    h, w = img_np.shape[:2]
    cx, cy = w // 2, h // 2
    ww, hh = max(1, int(w * 0.5)), max(1, int(h * 0.25))
    x1, y1 = max(0, cx - ww // 2), max(0, cy - hh // 2)
    crop = img_np[y1:y1 + hh, x1:x1 + ww]
    if crop.size == 0:
        cy2, cx2 = h // 2, w // 2
        hh2, ww2 = max(1, int(h * 0.25)), max(1, int(w * 0.5))
        crop = img_np[max(0, cy2 - hh2 // 2): max(0, cy2 + hh2 // 2),
                      max(0, cx2 - ww2 // 2): max(0, cx2 + ww2 // 2)]
    img_tf = tf.image.resize(crop, IMG_SIZE)
    img_tf = tf.cast(img_tf, tf.float32) / 255.0
    return img_tf.numpy()

def map_single(x, y):
    x0 = tf.squeeze(x, axis=0)
    out = tf.numpy_function(lambda a: preprocess_image_numpy(a), [x0], tf.float32)
    out.set_shape(IMG_SIZE + (3,))
    return out, y

print("Mapping dataset and batching...")
mapped = raw_ds.map(map_single, num_parallel_calls=AUTOTUNE)
ds = mapped.batch(BATCH).cache().prefetch(AUTOTUNE)

# freeze most layers
for layer in base.layers[:-6]:
    layer.trainable = False

base.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=LR),
             loss="binary_crossentropy", metrics=["accuracy"])
base.summary()

# callbacks: save weights only (weights filepath must end with .weights.h5)
callbacks = [
    tf.keras.callbacks.ModelCheckpoint(str(WEIGHTS_OUT), save_best_only=True, monitor="loss", mode="min", save_weights_only=True),
    tf.keras.callbacks.EarlyStopping(monitor="loss", patience=3),
]

print("Starting fine-tuning...")
history = base.fit(ds, epochs=EPOCHS, callbacks=callbacks, class_weight=class_weight_dict, verbose=1)

# ensure best weights loaded if checkpoint exists
try:
    base.load_weights(str(WEIGHTS_OUT))
    print("Loaded checkpoint weights:", WEIGHTS_OUT)
except Exception:
    print("No checkpoint weights found or failed to load; using current model weights.")

# save final full model in Keras native format
base.save(str(FINAL_MODEL_OUT))
print("Fine-tuning done. Final model saved at:", FINAL_MODEL_OUT)
