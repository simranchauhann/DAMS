# drowsiness_detector_mediapipe.py
"""
Drowsiness detector using MediaPipe face detection + CEW model.
- Uses MediaPipe Face Detection for robust face bbox
- Crops proportional eye ROIs from face bbox (left & right)
- Feeds cropped patches (resized to 96x96) to CEW model
- Keeps the same runtime controls as previous script:
    g -> label mode; o/c to save GT
    + / - -> adjust threshold
    s -> save snapshot
    q -> quit
Usage:
  python drowsiness_detector_mediapipe.py --save-log detections.csv
Install:
  py -3 -m pip install mediapipe
"""
import argparse
import time
from pathlib import Path
import csv
import sys

import cv2
import numpy as np

try:
    import mediapipe as mp
except Exception:
    mp = None

try:
    import tensorflow as tf
except Exception:
    tf = None

ROOT = Path(__file__).resolve().parent
DEFAULT_MODEL = ROOT / "models" / "cew_best.h5"
IMG_SIZE = (96, 96)

# parameters
CLOSED_PROB_THRESHOLD = 0.35
CLOSED_SECONDS_ALERT = 1.5
SCORE_SMOOTHING = 3

mp_face = mp.solutions.face_detection if mp else None

def save_log_row(csv_path, row):
    header = ['ts', 'frame_idx', 'closed_prob', 'predicted_closed', 'gt_label', 'notes']
    write_header = not Path(csv_path).exists()
    with open(csv_path, 'a', newline='') as f:
        writer = csv.writer(f)
        if write_header:
            writer.writerow(header)
        writer.writerow(row)

class MediapipeDrowsiness:
    def __init__(self, model_path: Path):
        if mp_face is None:
            raise RuntimeError("mediapipe not installed. pip install mediapipe")
        if tf is None:
            raise RuntimeError("tensorflow not available in this env")
        if not Path(model_path).exists():
            raise FileNotFoundError(f"Model not found at {model_path}")
        self.model = tf.keras.models.load_model(str(model_path))
        self.face_detector = mp_face.FaceDetection(model_selection=1, min_detection_confidence=0.4)
        self.score_window = []

    def crop_eye_rois_from_face(self, frame, bbox):
        """
        bbox: (xmin_rel, ymin_rel, width_rel, height_rel) from MediaPipe (values in [0,1])
        We'll crop left and right eye patches as fixed fractions of the face box.
        Returns list of patches (BGR)
        """
        h, w = frame.shape[:2]
        xmin = int(bbox[0] * w)
        ymin = int(bbox[1] * h)
        bw = int(bbox[2] * w)
        bh = int(bbox[3] * h)

        # Clip
        xmin = max(0, xmin)
        ymin = max(0, ymin)
        bw = max(1, min(bw, w - xmin))
        bh = max(1, min(bh, h - ymin))

        # Decide eye ROIs relative to face box
        # These fractions work well for frontal/near-frontal webcams; tweak if needed.
        # left eye box inside face:
        lx = xmin + int(0.12 * bw)
        ly = ymin + int(0.22 * bh)
        lw = int(0.26 * bw)
        lh = int(0.16 * bh)

        # right eye box
        rx = xmin + int(0.62 * bw)
        ry = ymin + int(0.22 * bh)
        rw = int(0.26 * bw)
        rh = int(0.16 * bh)

        # adjust to frame boundaries
        def get_patch(x, y, ww, hh):
            x1 = max(0, x); y1 = max(0, y)
            x2 = min(w, x1 + ww); y2 = min(h, y1 + hh)
            if x2 <= x1 or y2 <= y1:
                return None
            return frame[y1:y2, x1:x2]

        left_patch = get_patch(lx, ly, lw, lh)
        right_patch = get_patch(rx, ry, rw, rh)
        patches = []
        if left_patch is not None:
            patches.append(left_patch)
        if right_patch is not None:
            patches.append(right_patch)
        return patches, (lx, ly, lw, lh), (rx, ry, rw, rh)

    def predict_patch(self, patch):
        if patch is None or patch.size == 0:
            return 0.0
        img = cv2.resize(patch, IMG_SIZE)
        img = img.astype("float32") / 255.0
        img = np.expand_dims(img, 0)
        pred = self.model.predict(img, verbose=0).ravel()[0]
        return float(pred)

    def analyze_frame(self, frame):
        h, w = frame.shape[:2]
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.face_detector.process(rgb)
        probs = []
        draw = frame.copy()

        if results.detections:
            for det in results.detections:
                # MediaPipe bbox: relative, xywh normalized
                bb = det.location_data.relative_bounding_box
                bbox = (bb.xmin, bb.ymin, bb.width, bb.height)
                # draw face rect for debug
                x1 = int(bbox[0] * w); y1 = int(bbox[1] * h)
                x2 = x1 + int(bbox[2] * w); y2 = y1 + int(bbox[3] * h)
                cv2.rectangle(draw, (x1, y1), (x2, y2), (200,200,0), 2)

                patches, lrect, rrect = self.crop_eye_rois_from_face(frame, bbox)
                # visualize eye rects
                if lrect:
                    lx, ly, lw, lh = lrect
                    cv2.rectangle(draw, (lx, ly), (lx+lw, ly+lh), (0,255,0), 1)
                if rrect:
                    rx, ry, rw, rh = rrect
                    cv2.rectangle(draw, (rx, ry), (rx+rw, ry+rh), (0,255,0), 1)

                for p in patches:
                    prob = self.predict_patch(p)
                    probs.append(prob)
                    # small overlay of prob on the patch
                    # we won't annotate each patch further here (keeps UI clean)

        if len(probs) == 0:
            agg = 0.0
        else:
            agg = float(np.mean(probs))

        # smoothing
        self.score_window.append(agg)
        if len(self.score_window) > SCORE_SMOOTHING:
            self.score_window.pop(0)
        smooth = float(np.mean(self.score_window))
        return draw, smooth, len(probs)

def run(source, model_path, save_log=None, save_snaps=False):
    global CLOSED_PROB_THRESHOLD, CLOSED_SECONDS_ALERT
    det = MediapipeDrowsiness(Path(model_path))
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open source: {source}")
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    frames_alert = int(CLOSED_SECONDS_ALERT * fps)
    print(f"Video FPS: {fps} -> frames_alert={frames_alert}, threshold={CLOSED_PROB_THRESHOLD}")

    consecutive_closed = 0
    frame_idx = 0
    label_mode = False

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        annotated, closed_prob, n_eyes = det.analyze_frame(frame)
        predicted_closed = int(closed_prob >= CLOSED_PROB_THRESHOLD)
        if predicted_closed:
            consecutive_closed += 1
        else:
            consecutive_closed = 0

        cv2.putText(annotated, f"ClosedProb={closed_prob:.2f}", (10,22), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,200,255),2)
        cv2.putText(annotated, f"Consec={consecutive_closed}/{frames_alert}", (10,52), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,200,255),2)
        cv2.putText(annotated, f"Thresh={CLOSED_PROB_THRESHOLD:.2f}", (10,82), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,200,255),2)

        if consecutive_closed >= frames_alert:
            cv2.putText(annotated, "DROWSY! ALERT", (10,140), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0,0,255),3)
            if save_snaps:
                snap_p = ROOT / 'alert_snaps'
                snap_p.mkdir(exist_ok=True)
                fname = snap_p / f"alert_{int(time.time())}_f{frame_idx}.jpg"
                cv2.imwrite(str(fname), annotated)

        # logging
        if save_log:
            row = [time.time(), frame_idx, f"{closed_prob:.4f}", int(predicted_closed), None, ""]
            save_log_row(save_log, row)

        cv2.imshow("Drowsiness (MediaPipe)", annotated)
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('g'):
            label_mode = not label_mode
            print("Label mode:", label_mode)
        elif key == ord('o') and label_mode and save_log:
            save_log_row(save_log, [time.time(), frame_idx, f"{closed_prob:.4f}", int(predicted_closed), 0, "user_open"])
            print("Saved GT=open")
        elif key == ord('c') and label_mode and save_log:
            save_log_row(save_log, [time.time(), frame_idx, f"{closed_prob:.4f}", int(predicted_closed), 1, "user_closed"])
            print("Saved GT=closed")
        elif key == ord('+'):
            CLOSED_PROB_THRESHOLD = min(0.95, CLOSED_PROB_THRESHOLD + 0.05)
            print("Threshold ->", CLOSED_PROB_THRESHOLD)
        elif key == ord('-'):
            CLOSED_PROB_THRESHOLD = max(0.05, CLOSED_PROB_THRESHOLD - 0.05)
            print("Threshold ->", CLOSED_PROB_THRESHOLD)
        elif key == ord('s'):
            snap_p = ROOT / 'manual_snaps'
            snap_p.mkdir(exist_ok=True)
            fname = snap_p / f"snap_{int(time.time())}_f{frame_idx}.jpg"
            cv2.imwrite(str(fname), annotated)
            print("Saved snap ->", fname)

        frame_idx += 1

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument('--video', type=str, help='video file')
    ap.add_argument('--cam', type=int, default=0, help='camera index')
    ap.add_argument('--model', type=str, default=str(DEFAULT_MODEL))
    ap.add_argument('--save-log', type=str, help='log csv path')
    ap.add_argument('--save-snaps', action='store_true')
    args = ap.parse_args()

    src = args.video if args.video else args.cam
    run(src, args.model, save_log=args.save_log, save_snaps=args.save_snaps)
