# collect_eyes.py
import cv2
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "custom_cew"
open_dir = OUT / "open"
closed_dir = OUT / "closed"
open_dir.mkdir(parents=True, exist_ok=True)
closed_dir.mkdir(parents=True, exist_ok=True)

cap = cv2.VideoCapture(0)
print("Face forward. Press 'o' to capture OPEN, 'c' to capture CLOSED, 'q' to quit.")
idx_open = len(list(open_dir.glob("*.jpg")))
idx_closed = len(list(closed_dir.glob("*.jpg")))
while True:
    ret, frame = cap.read()
    if not ret:
        break
    cv2.putText(frame, "Press o=OPEN, c=CLOSED, q=QUIT", (10,30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,200,255), 2)
    cv2.imshow("Collect Eyes", frame)
    k = cv2.waitKey(1) & 0xFF
    if k == ord('o'):
        fname = open_dir / f"open_{idx_open:03d}.jpg"
        cv2.imwrite(str(fname), frame)
        print("Saved", fname)
        idx_open += 1
    elif k == ord('c'):
        fname = closed_dir / f"closed_{idx_closed:03d}.jpg"
        cv2.imwrite(str(fname), frame)
        print("Saved", fname)
        idx_closed += 1
    elif k == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
print("Done. Collected:", idx_open, "open,", idx_closed, "closed")
