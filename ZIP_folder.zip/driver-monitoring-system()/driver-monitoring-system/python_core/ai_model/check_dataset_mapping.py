# check_dataset_mapping.py
import tensorflow as tf
from pathlib import Path
ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "custom_cew"

ds = tf.keras.preprocessing.image_dataset_from_directory(
    DATA_DIR, labels='inferred', label_mode='binary', image_size=(128,128), batch_size=1, shuffle=False
)
print("class_names:", ds.class_names)
# Print first few labels to confirm order
print("First 20 items (filename, label):")
it = iter(ds.unbatch().take(20))
i = 0
for x,y in it:
    print(i, int(y.numpy()), end="  ")
    i+=1
print("\n(If class_names[0] == 'closed' then label 0=closed, 1=open)")
