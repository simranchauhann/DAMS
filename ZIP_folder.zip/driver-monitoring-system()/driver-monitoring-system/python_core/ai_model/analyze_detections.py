# analyze_detections.py
import pandas as pd
from pathlib import Path
p = Path("detections.csv")
if not p.exists():
    print("detections.csv not found")
    raise SystemExit
df = pd.read_csv(p)
# ensure closed_prob is numeric
df['closed_prob'] = df['closed_prob'].astype(float)
print("Rows:", len(df))
print("GT labeled rows (non-null gt_label):", df['gt_label'].notna().sum() if 'gt_label' in df.columns else 0)
print(df['closed_prob'].describe())
th = 0.35
preds = (df['closed_prob'] >= th).sum()
print(f"Predicted closed count at threshold {th}: {preds}")
print("Top 10 rows by closed_prob:")
print(df.sort_values('closed_prob', ascending=False).head(10))
