# pick_threshold_and_eval.py
import pandas as pd
import numpy as np
from sklearn.metrics import precision_recall_fscore_support, confusion_matrix

CSV = "detections.csv"
df = pd.read_csv(CSV)

# ensure numeric
df['closed_prob'] = pd.to_numeric(df['closed_prob'], errors='coerce')
print("Rows total:", len(df))
gt_rows = df[df['gt_label'].notna()].copy()
print("GT labeled rows:", len(gt_rows))
if len(gt_rows) == 0:
    print("No GT labels found. Use label mode (g then o/c) to add GT and re-run.")
    raise SystemExit

print("\nclosed_prob stats (all rows):")
print(df['closed_prob'].describe().to_string())

print("\nclosed_prob stats (GT rows only):")
print(gt_rows['closed_prob'].describe().to_string())

# function to compute metrics for a threshold
def metrics_for_threshold(th):
    y_true = gt_rows['gt_label'].astype(int).values
    y_pred = (gt_rows['closed_prob'] >= th).astype(int).values
    p, r, f1, _ = precision_recall_fscore_support(y_true, y_pred, average='binary', pos_label=1, zero_division=0)
    cm = confusion_matrix(y_true, y_pred)
    return p, r, f1, cm

# current threshold (what your detector uses)
current_th = 0.35
p, r, f1, cm = metrics_for_threshold(current_th)
print(f"\nCurrent threshold = {current_th:.2f} -> Precision={p:.3f}, Recall={r:.3f}, F1={f1:.3f}")
print("Confusion matrix (rows=true [open,closed], cols=pred [open,closed]):")
print(cm)

# search best threshold by F1
ths = np.arange(0.0, 1.0, 0.01)
best = {'th': None, 'f1': -1.0}
for t in ths:
    _, _, f, _ = metrics_for_threshold(t)
    if f > best['f1']:
        best = {'th': t, 'f1': f}

best_th = best['th']
p, r, f1, cm = metrics_for_threshold(best_th)
print(f"\nBest threshold by F1 = {best_th:.2f} -> Precision={p:.3f}, Recall={r:.3f}, F1={f1:.3f}")
print("Confusion matrix at best threshold:")
print(cm)

# show top GT rows where closed_prob is highest (helpful to inspect)
print("\nTop GT rows by closed_prob (highest 10):")
top = gt_rows.sort_values('closed_prob', ascending=False).head(10)
print(top[['frame_idx','closed_prob','predicted_closed','gt_label','notes']].to_string(index=False))
