# organize_nested_cew.py
# Usage:
#   python organize_nested_cew.py "C:/Users/vaibh/Downloads/folder1" ...

import argparse
import shutil
from pathlib import Path
import sys

# keywords for heuristics (more can be added)
OPEN_KEYS = ["open", "opened", "o_", "o-", "_o", "eyes_open", "eye_open", "openeye", "notclosed"]
CLOSED_KEYS = ["closed", "close", "closed_eye", "shut", "blink", "blinking", "c_", "c-", "_c", "eyes_closed", "eye_closed", "closedeye", "eyeshut"]

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}

def infer_label_from_text(text: str):
    s = text.lower()
    for k in CLOSED_KEYS:
        if k in s:
            return "closed"
    for k in OPEN_KEYS:
        if k in s:
            return "open"
    # sometimes filenames like L_close or R_open -> check both forms
    if "l_close" in s or "left_close" in s or "left_closed" in s or s.endswith("_lc"):
        return "closed"
    if "r_close" in s or "right_close" in s or s.endswith("_rc"):
        return "closed"
    if "l_open" in s or "left_open" in s or "leftopen" in s:
        return "open"
    if "r_open" in s or "right_open" in s or s.endswith("_ro"):
        return "open"
    return None

def process_sources(sources, out_dir: Path, mode="move"):
    out_dir.mkdir(parents=True, exist_ok=True)
    open_dir = out_dir / "open"
    closed_dir = out_dir / "closed"
    unknown_dir = out_dir / "unknown"
    open_dir.mkdir(exist_ok=True)
    closed_dir.mkdir(exist_ok=True)
    unknown_dir.mkdir(exist_ok=True)

    moved = {"open":0, "closed":0, "unknown":0}
    for src in sources:
        p = Path(src)
        if not p.exists():
            print(f"[WARN] Source not found: {p}")
            continue
        # walk recursively
        for f in p.rglob("*"):
            if not f.is_file(): continue
            if f.suffix.lower() not in IMAGE_EXTS: continue

            # try inference using filename and parent folder names (nearest few parents)
            candidates = [f.name]
            # also include parent names upto 3 levels
            ancestors = [a.name for a in f.parents][:3]
            candidates += ancestors

            label = None
            for txt in candidates:
                label = infer_label_from_text(txt)
                if label:
                    break

            # if still None, try checking characters like 'L'/'R' around names
            if label is None and any(part.lower() in ["left", "right", "l", "r"] for part in ancestors):
                # if sibling or filename contains 'close' or 'open' check there
                label = None
                # fallback remains None

            # choose dest
            if label == "open":
                dest_dir = open_dir
            elif label == "closed":
                dest_dir = closed_dir
            else:
                dest_dir = unknown_dir

            dest_dir.mkdir(parents=True, exist_ok=True)
            dest_path = dest_dir / f.name

            # avoid overwriting: if exists, append a suffix
            if dest_path.exists():
                base = dest_path.stem
                suf = dest_path.suffix
                i = 1
                while True:
                    new_name = f"{base}_{i}{suf}"
                    newp = dest_dir / new_name
                    if not newp.exists():
                        dest_path = newp
                        break
                    i += 1

            try:
                if mode == "move":
                    shutil.move(str(f), str(dest_path))
                else:
                    shutil.copy2(str(f), str(dest_path))
                moved["open" if label=="open" else "closed" if label=="closed" else "unknown"] += 1
            except Exception as e:
                print(f"[ERROR] {f} -> {dest_path} : {e}")

    print("Done.")
    print(f"Moved/copied counts: open={moved['open']}, closed={moved['closed']}, unknown={moved['unknown']}")
    print("Check the unknown folder and run interactive labeling if needed:", unknown_dir)
    return

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("sources", nargs="+", help="One or more source folders to scan recursively")
    parser.add_argument("--out", default="CEW_eye_patches", help="Output base folder name (default CEW_eye_patches)")
    parser.add_argument("--mode", choices=["move","copy"], default="move", help="move (default) or copy files")
    args = parser.parse_args()

    srcs = args.sources
    out_dir = Path(args.out).resolve()
    process_sources(srcs, out_dir, mode=args.mode)

if __name__ == "__main__":
    main()
