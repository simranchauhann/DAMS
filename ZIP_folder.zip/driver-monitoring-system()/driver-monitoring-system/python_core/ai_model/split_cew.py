﻿# split_cew.py
import os, random, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "CEW_eye_patches"
DST = ROOT / "data"

RATIOS = (0.8, 0.1, 0.1)  # train, val, test
SEED = 123

def split_data():
    random.seed(SEED)
    if not SRC.exists():
        print("❌ Source folder not found:", SRC)
        return

    classes = ["open", "closed"]
    for cls in classes:
        src_dir = SRC / cls
        if not src_dir.exists():
            print(f"⚠️ Missing class folder: {src_dir}")
            continue

        files = [f for f in src_dir.iterdir() if f.is_file()]
        random.shuffle(files)
        n = len(files)
        n_train = int(n * RATIOS[0])
        n_val = int(n * RATIOS[1])
        splits = {
            "train": files[:n_train],
            "val": files[n_train:n_train + n_val],
            "test": files[n_train + n_val:],
        }

        for split, items in splits.items():
            out_dir = DST / split / cls
            out_dir.mkdir(parents=True, exist_ok=True)
            for f in items:
                shutil.copy2(f, out_dir / f.name)
        print(f"✅ {cls}: total={n}, train={n_train}, val={n_val}, test={n - n_train - n_val}")

    print(f"📁 Data successfully split into: {DST}")
    
if __name__ == "__main__":
    split_data()
