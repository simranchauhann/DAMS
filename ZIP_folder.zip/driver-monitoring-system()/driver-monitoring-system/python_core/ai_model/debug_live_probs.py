# debug_live_probs.py
import cv2, time, numpy as np, sys
from pathlib import Path
import tensorflow as tf

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "models" / "cew_best.h5"
IMG_SIZE = (96,96)

if not MODEL_PATH.exists():
    print("Model not found:", MODEL_PATH); sys.exit(1)
model = tf.keras.models.load_model(str(MODEL_PATH))

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Cannot open camera"); sys.exit(1)

prev_gray = None
frame_idx = 0
print("Press Ctrl+C to stop. Showing per-frame debug in console.")
try:
    while True:
        ret, frame = cap.read()
        if not ret:
            print("frame not read - exiting"); break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # check change from previous frame
        if prev_gray is None:
            maxdiff = None
        else:
            diff = cv2.absdiff(prev_gray, gray)
            maxdiff = int(diff.max())
        prev_gray = gray

        # simple eye detection via OpenCV cascade (fast)
        eyes = []
        eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_eye.xml")
        eyes = eye_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
        patches = []
        for (ex,ey,ew,eh) in eyes[:4]:  # limit
            p = frame[ey:ey+eh, ex:ex+ew]
            patches.append(p)

        # if no eyes found, fallback: center crop (to test)
        if len(patches) == 0:
            h,w = frame.shape[:2]
            cx,cy = w//2, h//2
            ww = max(30, w//6); hh = max(20, h//8)
            p = frame[cy-hh:cy+hh, cx-ww:cx+ww]
            patches = [p]

        # predict for each patch and report mean
        probs = []
        for p in patches:
            try:
                im = cv2.resize(p, IMG_SIZE)
                im = im.astype("float32")/255.0
                pred = model.predict(np.expand_dims(im,0), verbose=0).ravel()[0]
                probs.append(float(pred))
            except Exception as e:
                probs.append(0.0)

        agg = float(np.mean(probs)) if probs else 0.0
        print(f"frame={frame_idx:04d} maxdiff={maxdiff} patches={len(patches)} closed_prob={agg:.4f}")
        frame_idx += 1
        # show one frame to verify UI updates
        cv2.imshow("dbg", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        time.sleep(0.01)
finally:
    cap.release()
    cv2.destroyAllWindows()
